@extends('layouts.template')
@section('content')


    <div class="col-8 col-lg-8">
      <!-- Inventory Start -->
      <h2 class="small-title">Assign Role</h2>
      
   
      <!-- Today's Orders End -->

      <!-- Categories End -->
    </div>



@endsection