@include('layouts.header')
@include('layouts.sidemenu')

    @yield('content')
  </div>
</div>
</main>
@include('layouts.footer')
    
</body>
</html>