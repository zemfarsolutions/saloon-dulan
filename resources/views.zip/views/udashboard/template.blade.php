@include('udashboard.header')
@include('udashboard.sidemenu')

    @yield('content')
  </div>
</div>
</main>
@include('udashboard.footer')
    
</body>
</html>