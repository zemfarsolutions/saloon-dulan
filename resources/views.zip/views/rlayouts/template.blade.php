@include('rlayouts.header')
@include('rlayouts.sidemenu')

    @yield('content')
  </div>
</div>
</main>
@include('rlayouts.footer')
    
</body>
</html>