@include('rlayouts.header')
@include('rlayouts.sidemenu')

    @yield('content')
  </div>
</div>
</main>

    
</body>
</html>